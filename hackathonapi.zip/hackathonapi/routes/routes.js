var appRouter = function (app) {
    app.get("/", function(req, res) {
      res.status(200).send("Welcome to our restful API");
    });
    app.get("/getcustspend/:arn",function(req,res){
        var mongoClient = require('mongodb').MongoClient;
        var url = 'mongodb://admin:Pkdstulu1025@ds241570.mlab.com:41570/adminapi';
        var resp=[];
        mongoClient.connect(url, function(err, db) {
            if (err) throw err;
            var arnNum = req.params.arn;
            var dbo = db.db("adminapi");
            var query = { ARN:parseInt(arnNum) };
            dbo.collection("ARN_Spends").find(query).toArray(function(err, result) {
                if (err) throw err;
                db.close();
                res.status(200).send(result);
            }); 
        });
        
    });
    app.get("/getcatagory",function(req,res){
        var mongoClient = require('mongodb').MongoClient;
        var url = 'mongodb://admin:Pkdstulu1025@ds241570.mlab.com:41570/adminapi';
        var resp=[];
        mongoClient.connect(url, function(err, db) {
            if (err) throw err;
            var arnNum = req.params.arn;
            var dbo = db.db("adminapi");
            var query = { ARN:parseInt(arnNum) };
            dbo.collection("Categorical_Emission").find().toArray(function(err, result) {
                if (err) throw err;
                db.close();
                res.status(200).send(result);
            }); 
        });
        
    })
  }
  
  module.exports = appRouter;

  /*result[0].TRAN_DTL.forEach(element => {
    dbo.collection("Categorical_Emission").find({ MID: { $all:[element.MID] } })
    .toArray(function(er,rs){
        element.MID=rs[0].category;
        console.log(rs[0].category);

    });
 });*/